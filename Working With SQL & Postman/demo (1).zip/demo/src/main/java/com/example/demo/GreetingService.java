package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@Transactional
public class GreetingService {
    @Autowired
    private JdbcGreetingRepository greetingRepository;

    public List<Greeting> getAllGreetings() {
        return greetingRepository.getAllGreetings();
    }
    
    public Greeting getGreetingById(Long id) {
        return greetingRepository.getGreetingById(id);
    }
    
    public void saveGreeting(Greeting greeting) {
        greetingRepository.saveGreeting(greeting);
    }
    
    public void updateGreeting(Greeting greeting) {
        greetingRepository.updateGreeting(greeting);
    }
    
    public void deleteGreetingById(Long id) {
        greetingRepository.deleteGreetingById(id);
    }
}
