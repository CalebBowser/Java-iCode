package com.example.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;
import javax.sql.DataSource;
import jakarta.annotation.PostConstruct;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class JdbcGreetingRepository {

    @Autowired
    private DataSource dataSource;
    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    private void initialize() {
        jdbcTemplate = new JdbcTemplate(dataSource);
    }

    public List<Greeting> getAllGreetings() {
        String sql = "SELECT * FROM greetings";
        return jdbcTemplate.query(sql, (rs, rowNum) -> {
            Greeting greeting = new Greeting();
            greeting.setId(rs.getLong("id"));
            greeting.setMessage(rs.getString("message"));
            return greeting;
        });

    }

    @SuppressWarnings("deprecation")
    public Greeting getGreetingById(long id) {
        String sql = "SELECT * FROM greetings WHERE id = ?";
        return jdbcTemplate.queryForObject(sql, new Object[]{id}, (rs, rowNum) -> {
            Greeting greeting = new Greeting();
            greeting.setId(rs.getLong("id"));
            greeting.setMessage(rs.getString("message"));
            return greeting;
        });
    }

    public void saveGreeting(Greeting greeting) {
        String sql = "INSERT INTO greetings (message) VALUES (?)";
        jdbcTemplate.update(sql, greeting.getMessage());
    }

    public void updateGreeting(Greeting greeting) {
        String sql = "UPDATE greetings SET message = ? WHERE id = ?";
        jdbcTemplate.update(sql, greeting.getMessage(), greeting.getId());
    }

    public void deleteGreetingById(Long id) {
        String sql = "DELETE FROM greetings WHERE id = ?";
        jdbcTemplate.update(sql, id);
    }
}










